<?php 
	header('Location: controllers/controller.php');
 ?>