<?php 
	$dsn = 'mysql:host=localhost;dbname=userphp27';
	$username='root';
	$password='';
	$options = array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::MYSQL_ATTR_INIT_COMMAND=>"SET NAMES utf8");
	try{
		$db = new PDO($dsn, $username, $password, $options);
	}
	catch(PDOException $e){
		$error_message = $e->getMessage();
		echo "<p>Error connecting to database: $error_message</p>";
		exit();
	}
	function getalluser(){
		global $db;
		try{
			$query = "SELECT * FROM usertable";
			$statement=$db->prepare($query);
			$statement->execute();
			$users = $statement->fetchAll();
			$statement->closeCursor();
			return $users;
		} catch(PDOException $e){
			$error_message = $e->getMessage();
			echo "<p>Error connecting to database: $error_message</p>";
			exit();
		}
	}
 ?>