<?php 
	include("../model/model_database.php");
	$action = filter_input(INPUT_POST, 'action');
	if (empty($action)) {
		$action = filter_input(INPUT_GET, 'action');
		if (empty($action)){
			$action = 'show_list_user';
		}
	}
	switch ($action) {
		case 'show_list_user':
			$users = getalluser();
			include('../views/list_user.php');
			break;
		
		default:
			# code...
			break;
	}
 ?>